# EMNLP-format manuscript

**SARRA: Attack Resistance Is Only Half the Answer for Search Agents** uses the official, unmodified ACL LaTeX template required by EMNLP/ARR. The introduction opens with a saved film-comparison error and follows the gap between attack resistance and correct task completion. The empirical contribution is a bounded export-level comparison, rather than a new defensive-training algorithm.

## PDFs

- `paper-review.pdf`: anonymous review version, with line numbers.
- `paper-public.pdf`: named preprint version for reading and the project website. It is not a camera-ready or accepted paper.

Both versions have **8 pages of main content**. Limitations, ethical considerations, assistance disclosure, references, and double-column appendices follow. The complete PDF has 25 pages in the checked build. EMNLP 2026 permits 8 main-content pages for initial long-paper submissions; 9 is the accepted final-version allowance. The main text was not padded to 9 pages or moved into Limitations to evade that limit.

## Abstract and reproducibility appendix revision

The abstract is rewritten as a 184-word account of the question, design, primary result, transfer scope, and historical export qualification. The appendix expands from two to fourteen pages (pages 12–25, beginning after the final references), covering split construction, exact task/chat/observation prompts, every primary attack, length-matched benign controls, quota allocation, answer selection and token masks, effective hyperparameters, every run's costs, inference/scoring/bootstrap details, context-control supervision, all 17 transfer conditions and eight candidate payloads, and exact case terminal outputs.

Twenty prompt/interface text files and three case panels are in `prompts/`; `data/prompt-catalog.json` preserves exact whitespace and the transfer target bank. `make_appendix_assets.py --project-root PATH` extracts these from frozen project sources and verifies their hashes; it requires the retained project archive. Selected source excerpts are in `reproduction/`, and split identities and additional accounting are in `data/`. They document the historical procedure and do not constitute a complete portable training release. No new model inference or training was performed.

The revision also corrects two previously imprecise descriptions: repetitions 2 and 3 share a training template within a selected group; evaluation shares the first autonomous action within each model/question across its five conditions. The appendix distinguishes training consumption from the primary evaluator's observation-level exposure flag.

## Layout and author revision

The named version lists Yiwen Lu, University of Notre Dame, and ylu37@nd.edu. The anonymous review PDF excludes this information. The appendix now follows the bibliography without a forced page break, removing the mostly blank reference-tail page. Figure 1 uses distinct seed colors/shapes and black mean diamonds; gray segments show the observed seed range, not a confidence interval. The primary and transition tables use their available widths and more legible row spacing. Figures and tables retain the same numerical data.

## Exploratory diagnostics revision

The main figure uses Seed 1–3, with original integers retained in the Appendix A mapping. Appendix I documents zero-reward supervision counts, recovery and repeated-evidence controls, query/state-extraction diagnostics, and the completed 36-state simple-action experiment. Its observations are explicitly separated from causal explanations and confirmation results. Diagnostic aggregate records and source hashes are in `data/exploratory-diagnostics.json`; the simple-action prompt code is included. The 36 saved states were re-scored against the original scorer without rewriting their records or running inference.

## Narrative revision

The approved title centers the user-task question. The introduction opens with the existing Case C film trace, the results follow gains, clean/cost checks, paired outcomes, and transfer, and three cases connect the means to saved answers. The discussion returns to the opening example and links the recovery diagnostics to future action-policy work. The abstract, PDF metadata, citation contexts and website download heading are synchronized. Original quantitative records, all 46 bibliography entries, and material qualifications are preserved. See `narrative-review.txt` for the revision review.

## Literature revision

There are **45 scholarly papers and one software reference**, up from 10 papers and one software reference. Every entry is cited in the manuscript; there is no uncited bibliography padding. New related-work paragraphs distinguish search-policy learning, attack settings, structural defenses, supervised/preference/RL defenses, recovery, and evidence-use evaluation. SecAlign, SecOPD, SelectBench, ARLAS, and AgentSentry explicitly delimit the present claim.

`literature-audit.json` maps each reference to its role, primary source, bibliographic metadata, inspection scope, and citation paragraphs. Primary landing-page metadata and abstracts were checked for all 45 papers; this does not imply complete reading or independent replication of every paper. The audit does not redistribute the source abstracts. It records the ACL/PDF first-name discrepancy for the surface-heuristics paper. Conference metadata is used where obtained directly from the publisher; remaining entries identify the verified arXiv version, without asserting an unverified venue.

## Build / Overleaf

Upload the source ZIP into Overleaf and select `paper.tex` as the main document, using pdfLaTeX. It defaults to anonymous review mode. For a named preprint, compile with `\def\publicversion{1}\input{paper.tex}`, as in `build.sh`.

Locally:

```sh
bash build.sh
```

The generated tables and figure are included. To regenerate them from the included JSON summaries, run `python make_assets.py` with Matplotlib installed. Re-running `analyze_cases.py --project-root PATH` additionally requires the original project trajectory archive; it does not call a model or change training. The historical model and protocol hashes are retained in `data/`.

The ACL style files are pinned in `template-provenance.json`. The included unmodified `lineno.sty` updates the old system line-number package for this build; its upstream source and hash are recorded in `dependency-provenance.json`. The build runs sufficient passes to stabilize line positions after bibliography and float placement. It does not modify margins, fonts, spacing, or the ACL style to fit the page limit.

## Evidence additions

The new paired analysis re-scores 30,000 saved trajectories from the two primary configurations (three seeds, 1,000 questions, five conditions). It analyzes 6,000 malicious-condition pairs sharing 1,000 question identities. There are 931 wrong-to-correct and 327 correct-to-wrong comparisons, a net difference of 604, consistent with the original 10.07 percentage-point result.

The three cases are selected post hoc using explicit rules: first seed, both clean answers correct, first lexicographic ID/condition per category; Case A also requires identical first query and clean documents. Their raw actions, evidence, answers, selection rules, and source hashes are included in `data/cases.json` and `data/paired-analysis.json`. These are explanations of saved behavior, not new confirmation or mechanism experiments.

The prior historical train/export consistency limitation remains in the abstract, experimental protocol, and Limitations. Best runs remain separate from configuration means. Unsuccessful recovery pilots remain outside the positive contributions. The document is a submission-format working draft requiring author review; template compliance does not establish scientific readiness or acceptance.

## Sources for requirements

- [EMNLP 2026 main conference call](https://2026.emnlp.org/calls/main_conference_papers/)
- [ARR call and submission requirements](https://aclrollingreview.org/cfp)
- [Official ACL style repository](https://github.com/acl-org/acl-style-files)

Requirements were checked on 2026-10-08. EMNLP 2026's submission and camera-ready deadlines have already passed; this package uses its published format, not an available submission opportunity. Check the target cycle's current requirements before an actual submission.
