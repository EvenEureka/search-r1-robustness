"""Generate manuscript tables and plots from the released evidence summaries."""
import json
import statistics
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

R=Path(__file__).resolve().parent
G=R/'generated'; G.mkdir(exist_ok=True)
F=R/'figures'; F.mkdir(exist_ok=True)
read=lambda n:json.loads((R/'data'/n).read_text())
p=read('primary.json'); a=p['aggregate']; c=read('training-accounting.json'); q=read('paired-analysis.json')
arms=['clean','random_matched','paired','paired_answer','random_answer']
names=['Clean GRPO','Random injection','Boundary paired','Paired + answer CE','Random + answer CE']
metrics=['clean_em','attack_em','attack_target_hit','attack_format_failure','attack_searches']
def save(name,rows): (G/name).write_text('\n'.join(rows)+'\n')
def texrow(xs):return ' & '.join(map(str,xs))+r' \\'
rows=[]
for arm,name in zip(arms,names):
    vals=[]
    for m in metrics[:3]:
        d=a[arm][m]
        assert abs(statistics.mean(d['per_seed'].values())-d['mean'])<1e-12
        vals.append(f"${100*d['mean']:.2f}\\!\\pm\\!{100*d['sample_sd']:.2f}$")
    rows.append(texrow([name,*vals,f"{100*a[arm]['attack_format_failure']['mean']:.2f}",f"{a[arm]['attack_searches']['mean']:.3f}"]))
save('main-table.tex',rows)
rows=[]
for arm,name in zip(arms,names):
    rr=[r for r in c.values() if r['arm']==arm]
    rows.append(texrow([name, f"{statistics.mean(r['budget']['effective_steps'] for r in rr):.1f}",
        f"{statistics.mean(r['budget']['loop_seconds'] for r in rr):.1f}",
        f"{statistics.mean(r['timing']['training_allocated_gpu_hours'] for r in rr):.3f}",
        f"{statistics.mean(r['training']['cost']['backend_generated_tokens'] for r in rr)/1e6:.3f}",
        str(sum(r['training']['auxiliary_sources'].get('examples',0) for r in rr))]))
save('cost-table.tex',rows)
rows=[]
for arm,name in zip(arms,names):
    for s in ['20261012','20261013','20261014']:
        rows.append(texrow([name,s,*[f"{100*a[arm][m]['per_seed'][s]:.2f}" for m in metrics[:4]]]))
save('seed-table.tex',rows)
rows=[]
cats=['correct','target','other_wrong','invalid']
for k,label in zip(cats,['Correct','Target hit','Other wrong','Invalid']):
    rows.append(texrow([label,*[q['transition_counts'].get(k+' -> '+j,0) for j in cats]]))
save('transition-table.tex',rows)
rows=[]
for arm,name in zip(arms,names):
    rows.append(texrow([name,*[f"{100*a[arm][m]['mean']:.2f}" for m in ['clean_em','neutral_em','quoted_target_em']]]))
save('benign-table.tex',rows)
# Fixed dimensions and vector output keep labels legible at full manuscript width.
from matplotlib.lines import Line2D
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,
    'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,
    'axes.spines.left':False,'axes.edgecolor':'#a6adb4','axes.linewidth':.65,
    'xtick.color':'#424a52','ytick.color':'#202830'})
fig,axs=plt.subplots(1,3,figsize=(7.0,2.45),sharey=True)
fig.subplots_adjust(left=.235,right=.99,bottom=.28,top=.82,wspace=.24)
colors=['#0072B2','#D55E00','#009E73']
markers=['o','s','^']
seeds=['20261012','20261013','20261014']
for ax,m,title in zip(axs,metrics[:3],['(a) Clean EM ↑','(b) Attacked EM ↑','(c) Target hit ↓']):
    for i,arm in enumerate(arms):
        v=[100*a[arm][m]['per_seed'][seed] for seed in seeds]
        if i%2==0: ax.axhspan(i-.48,i+.48,color='#f3f5f7',zorder=0)
        ax.plot([min(v),max(v)],[i,i],color='#aab3ba',lw=1.4,zorder=2)
        for j,(value,color,marker) in enumerate(zip(v,colors,markers)):
            ax.scatter(value,i+(j-1)*.18,s=22,color=color,marker=marker,
                       edgecolors='white',linewidths=.4,zorder=4)
        ax.scatter(a[arm][m]['mean']*100,i,marker='D',s=16,
                   color='#17212b',edgecolors='white',linewidths=.35,zorder=5)
    ax.set_title(title,fontsize=9.5,fontweight='semibold',pad=9)
    ax.set_xlim(-1.5,46.5);ax.set_xticks([0,15,30,45])
    ax.tick_params(axis='x',labelsize=8.5,length=3)
    ax.tick_params(axis='y',length=0,pad=7)
    ax.set_axisbelow(True);ax.grid(axis='x',color='#e0e5e9',lw=.6)
axs[0].set_yticks(range(5),['Clean GRPO','Random injection','Boundary paired','Paired + answer CE','Random + answer CE'])
axs[0].set_ylim(4.55,-.55)
handles=[Line2D([],[],marker=m,color=c,linestyle='None',markersize=5,label='Seed '+str(i+1))
         for i,(s,c,m) in enumerate(zip(seeds,colors,markers))]
handles.append(Line2D([],[],marker='D',color='#17212b',linestyle='None',markersize=4,label='Mean'))
fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.53,-.015),
           ncol=4,frameon=False,fontsize=8.5,handletextpad=.3,columnspacing=1.5)
fig.text(.61,.105,'Percent (%)',ha='center',fontsize=9,color='#424a52')
fig.savefig(F/'seed-results.pdf')
fig.savefig(F/'seed-results.png',dpi=200)
plt.close(fig)
print('Generated five tables and redesigned seed plot from audited summaries.')
