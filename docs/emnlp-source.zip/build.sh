#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build -jobname=paper-review paper.tex >build/review-pass1.txt
bibtex build/paper-review >build/review-bibtex.txt
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build -jobname=paper-review paper.tex >build/review-pass2.txt
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build -jobname=paper-review paper.tex >build/review-pass3.txt
# Two-column line references can need extra passes after bibliography/float placement.
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build -jobname=paper-review paper.tex >build/review-pass4.txt
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build -jobname=paper-review paper.tex >build/review-pass5.txt
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build -jobname=paper-public '\def\publicversion{1}\input{paper.tex}' >build/public-pass1.txt
bibtex build/paper-public >build/public-bibtex.txt
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build -jobname=paper-public '\def\publicversion{1}\input{paper.tex}' >build/public-pass2.txt
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build -jobname=paper-public '\def\publicversion{1}\input{paper.tex}' >build/public-pass3.txt
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build -jobname=paper-public '\def\publicversion{1}\input{paper.tex}' >build/public-pass4.txt
cp build/paper-review.pdf paper-review.pdf
cp build/paper-public.pdf paper-public.pdf
