"""Evaluate the frozen confirmation split with the unchanged development engine."""
import argparse
import hashlib
import json
import os
import platform
import sys
import time
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('directory', type=Path)
p.add_argument('--run-index', type=int, required=True)
p.add_argument('--shard', type=int, required=True)
p.add_argument('--shards', type=int, default=4)
a = p.parse_args()
plan = json.loads((a.directory / 'protocol.json').read_text())
entry = plan['runs'][a.run_index]
a.run = Path(entry['output'])
source = Path(plan['source'])
sys.path.insert(0, str(source / 'scripts'))
sys.path.insert(0, str(source / 'arr_study'))
from engine_v2 import boundary, episode
from evaluation import normalize, score_record
import torch
import transformers
from transformers import AutoModelForCausalLM, AutoTokenizer, StoppingCriteria, StoppingCriteriaList

assert os.environ.get('JOB_ID') and torch.cuda.is_available()
samples_path = Path(plan['confirmation_split'])
assert hashlib.sha256(samples_path.read_bytes()).hexdigest() == plan['confirmation_sha256']
samples = [json.loads(s) for s in samples_path.read_text().splitlines()][a.shard::a.shards]
assert samples and 0 <= a.shard < a.shards
out = a.run / f'confirmation/shard_{a.shard}'
assert not out.exists(), out
out.mkdir(parents=True)
cfg = plan['evaluation']
model_path = Path(entry['model'])
torch.manual_seed(cfg['seed'])
torch.set_num_threads(2)
tok = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
started = time.monotonic()
model = AutoModelForCausalLM.from_pretrained(model_path, dtype=torch.bfloat16, attn_implementation='sdpa', local_files_only=True).to('cuda').eval()

class Stop(StoppingCriteria):
    def __init__(self, start): self.start = start
    def __call__(self, input_ids, scores, **kw):
        tail = tok.decode(input_ids[0, max(self.start, input_ids.shape[1]-32):], skip_special_tokens=True)
        return '</search>' in tail or '</answer>' in tail

work = {'requested_input_tokens': 0, 'generated_tokens': 0, 'calls': 0}

@torch.inference_mode()
def generate(prompt):
    x = tok(prompt, return_tensors='pt').to('cuda')
    y = model.generate(**x, max_new_tokens=cfg['max_new_tokens_per_turn'], do_sample=False,
        pad_token_id=tok.eos_token_id, stopping_criteria=StoppingCriteriaList([Stop(x['input_ids'].shape[1])]))
    work['requested_input_tokens'] += x['input_ids'].shape[1]
    work['generated_tokens'] += y.shape[1] - x['input_ids'].shape[1]
    work['calls'] += 1
    return tok.decode(y[0, x['input_ids'].shape[1]:], skip_special_tokens=True)

def fmt(prompt):
    return tok.apply_chat_template([{'role': 'user', 'content': prompt}], add_generation_prompt=True, tokenize=False) if tok.chat_template else prompt

environment = {'job': os.environ['JOB_ID'], 'host': platform.node(), 'gpu': torch.cuda.get_device_name(0),
    'torch': torch.__version__, 'transformers': transformers.__version__, 'model': str(model_path),
    'confirmation_sha256': plan['confirmation_sha256'], 'shard': a.shard, 'shards': a.shards,
    'config_sha256': hashlib.sha256((model_path / 'config.json').read_bytes()).hexdigest()}
(out / 'environment.json').write_text(json.dumps(environment, indent=2))
total = 0
with (out / 'traces.jsonl').open('x') as stream:
    for sample in samples:
        assert all(normalize(answer) != normalize(cfg['attack_target']) for answer in sample['answers'])
        own = boundary(sample, cfg, generate, lambda s: len(tok.encode(s)), fmt)
        for condition in cfg['conditions']:
            row = episode(sample, own, condition, 'end_to_end', cfg, generate, lambda s: len(tok.encode(s)))
            assert row['metrics']['em'] == score_record(row)['em']
            row.update(model=entry['arm'], training_seed=entry['seed'])
            stream.write(json.dumps(row) + '\n'); stream.flush()
            total += 1
        print('CONFIRM_PROGRESS', a.shard, total, flush=True)
assert total == len(samples) * len(cfg['conditions'])
(out / 'COMPLETE.json').write_text(json.dumps({'status': 'COMPLETE', 'records': total, 'seconds': time.monotonic()-started, 'work': work}, indent=2))
