"""All planned arms/seeds required; paired questions, no outcome-based exclusions."""
import json
import sys
from pathlib import Path
import numpy as np
from confirmation_utils import digest, verify

directory = Path(sys.argv[1])
plan = json.loads((directory / 'protocol.json').read_text())
verify(plan['files'])
results = {}
for entry in plan['runs']:
    out = Path(entry['output'])
    assert (out / 'CONFIRMATION_RUN_VALIDATED').exists(), out
    assert (out / 'exit_code.txt').read_text().strip() == '0'
    r = json.loads((out / 'result.json').read_text())
    assert r['protocol_sha256'] == digest(directory / 'protocol.json')
    assert r['records'] == 5000 and len(r['ids']) == 1000
    assert r['seed'] == entry['seed'] and r['arm'] == entry['arm']
    results[(r['seed'], r['arm'])] = r
seeds, arms = plan['seeds'], plan['arms']
assert set(results) == {(s, a) for s in seeds for a in arms}
ids = results[(seeds[0], arms[0])]['ids']
assert all(r['ids'] == ids for r in results.values())
aggregate = {}
for arm in arms:
    aggregate[arm] = {}
    for metric in results[(seeds[0], arm)]['vectors']:
        values = [float(np.mean(results[(s, arm)]['vectors'][metric])) for s in seeds]
        aggregate[arm][metric] = {'per_seed': dict(zip(map(str, seeds), values)),
            'mean': float(np.mean(values)), 'sample_sd': float(np.std(values, ddof=1))}
contrasts = {}
rng = np.random.default_rng(plan['analysis']['bootstrap_seed'])
for left, right in plan['analysis']['contrasts']:
    contrast = contrasts[f'{left}_minus_{right}'] = {}
    for metric in ['attack_em', 'attack_target_hit', 'clean_em']:
        delta = np.array([results[(s, left)]['vectors'][metric] for s in seeds]) - np.array([results[(s, right)]['vectors'][metric] for s in seeds])
        nested, fixed = [], []
        for _ in range(plan['analysis']['bootstrap_draws']):
            qq = rng.integers(0, len(ids), len(ids))
            ss = rng.integers(0, len(seeds), len(seeds))
            nested.append(float(delta[ss][:, qq].mean()))
            fixed.append(float(delta[:, qq].mean()))
        contrast[metric] = {'per_seed_differences': dict(zip(map(str, seeds), delta.mean(axis=1).tolist())),
            'mean_difference': float(delta.mean()), 'question_bootstrap_95pct_interval_fixed_models': np.quantile(fixed, [.025, .975]).tolist(),
            'descriptive_nested_95pct_interval': np.quantile(nested, [.025, .975]).tolist()}
report = {'status': 'ALL_15_CONFIRMATION_RUNS_COMPLETE', 'protocol_sha256': digest(directory / 'protocol.json'),
    'questions': len(ids), 'records': sum(r['records'] for r in results.values()), 'aggregate': aggregate,
    'contrasts': contrasts, 'limitations': plan['limitations'],
    'per_run': {f'{s}/{a}': {k: v for k, v in r.items() if k not in ('vectors', 'ids')} for (s, a), r in results.items()}}
(directory / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
lines = ['Frozen 1000-question confirmation, all 15 models', '', 'arm clean_EM attacked_EM attack_target_hit']
for arm, rr in aggregate.items():
    lines.append(f"{arm} {rr['clean_em']['mean']:.6f} {rr['attack_em']['mean']:.6f} {rr['attack_target_hit']['mean']:.6f}")
lines += ['', *plan['limitations']]
(directory / 'comparison.txt').write_text('\n'.join(lines) + '\n')
registry = json.loads((directory / 'jobs.json').read_text())
registry['stage'] = report['status']
(directory / 'jobs.json').write_text(json.dumps(registry, indent=2) + '\n')
print('\n'.join(lines))
