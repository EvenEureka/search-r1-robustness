"""Change only the first retrieved observation in the auxiliary CE input."""
from scripts.evaluation import ATTACKS, format_documents, inject
from training_adapter.quota_trainer import select_answer_examples

def observation_ids(tokenizer, documents):
    text = '\n\n<information>' + format_documents(documents).strip() + '</information>\n\n'
    return tokenizer.encode(text, add_special_tokens=False)

def clean_counterpart(record, tokenizer, target):
    """Exact suffix replacement preserves every token before the observation."""
    attacked = observation_ids(tokenizer, inject(record['clean_documents'], record['template'], target))
    clean = observation_ids(tokenizer, record['clean_documents'])
    ids = record['continuation_input_ids']
    assert attacked and ids[-len(attacked):] == attacked, 'Observation tokenization does not match the pinned generator'
    prefix = ids[:-len(attacked)]
    return prefix + clean, len(prefix), len(attacked), len(clean)

def context_examples(records, output, tokenizer, support, max_length, mode, target):
    assert mode in ('clean', 'attacked')
    # Eligibility/label choice is always evaluated on the original attacked input.
    # Thus cleaning the shorter input cannot admit extra labels within a batch.
    examples, counts = select_answer_examples(records, output, tokenizer, support, max_length)
    attacked_rows = {r['group']: r for r in records if r.get('auxiliary_selected') and r['repetition'] == 2}
    result = []
    for ex in examples:
        row = attacked_rows[ex['group']]
        clean, prefix_length, attacked_length, clean_length = clean_counterpart(row, tokenizer, target)
        old_ids = row['continuation_input_ids']
        suffix = tokenizer.encode('\n<answer>', add_special_tokens=False)
        assert ex['prompt_ids'] == old_ids + suffix
        prompt = (clean if mode == 'clean' else old_ids) + suffix
        assert len(prompt) + len(ex['response_ids']) <= max_length
        result.append({**ex, 'prompt_ids': prompt, 'context_mode': mode,
            'counterfactual_clean_input_ids': clean, 'original_attacked_input_ids': old_ids,
            'shared_prefix_tokens': prefix_length, 'attacked_observation_tokens': attacked_length,
            'clean_observation_tokens': clean_length})
    return result, counts
