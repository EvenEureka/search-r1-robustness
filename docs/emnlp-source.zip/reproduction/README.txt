HISTORICAL SOURCE EXCERPTS

These files are copied from the frozen local primary-evaluation, training-adapter, and context-control snapshots. Their original relative paths and SHA256 hashes are recorded in data/appendix-provenance.json. They are research evidence, not a standalone runnable training package. They depend on the pinned upstream SkyRL environment, dataset schema, full run protocols, model weights and historical project layout; these are not all redistributed here.

The historical embedding/output weight-sharing qualification remains material. Reusing this code without validating train/inference/export parameter consistency is not a corrected replication. The exact experiment prompts and reduced results are available separately in prompts/ and data/. No new model outputs were generated for this appendix.
