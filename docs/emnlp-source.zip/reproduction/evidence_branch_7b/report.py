import json,hashlib
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parents[1];plan=json.loads((HERE/'protocol.json').read_text());out={}
from branch import eligible
original={(r['id'],r['condition']):r for path in plan['trace_files'] for r in map(json.loads,Path(path).read_text().splitlines()) if r['condition'] in plan['conditions']}
rows=[r for path in (HERE/'runs').glob('*/traces.jsonl') for r in map(json.loads,path.read_text().splitlines())]
lookup={(r['id'],r['condition'],r['branch']):r for r in rows};assert len(lookup)==len(rows)
expected={(i,c,b) for (i,c),r in original.items() if eligible(r) for b in ['new','repeat']};assert set(lookup)==expected
metrics=['em','target_hit','other_wrong','format_failure','searches','actual_exposure']
for condition in plan['conditions']:
 ids=sorted(i for i,c in original if c==condition);selected=[i for i in ids if eligible(original[i,condition])];assert len(ids)==256
 r={'all_question_denominator':len(ids),'eligible_states':len(selected),'eligibility_rate':len(selected)/len(ids),'branches':{}}
 for branch in ['new','repeat']:
  paired=[lookup[i,condition,branch] for i in selected]
  whole=[lookup[i,condition,branch] if i in selected else original[i,condition] for i in ids]
  r['branches'][branch]={'eligible_mean':{m:sum(x['metrics'][m] for x in paired)/len(paired) if paired else None for m in metrics},'all_question_mean':{m:sum(x['metrics'][m] for x in whole)/len(whole) for m in metrics},'budget_exhausted':sum(x['stop_reason']=='search_limit' for x in paired),'context_limit':sum(x['stop_reason']=='context_limit' for x in paired),'continuation_cost':{m:sum(x['continuation_work'][m] for x in paired) for m in ['calls','requested_input_tokens','generated_tokens']},'continuation_seconds':sum(x['continuation_seconds'] for x in paired)}
 new=[lookup[i,condition,'new'] for i in selected];repeat=[lookup[i,condition,'repeat'] for i in selected]
 delta=np.array([x['metrics']['em']-y['metrics']['em'] for x,y in zip(new,repeat)],dtype=float)
 rng=np.random.default_rng(plan['bootstrap_seed']);boots=np.array([rng.choice(delta,len(delta),replace=True).mean() for _ in range(plan['bootstrap_draws'])]) if len(delta) else []
 r.update(new_minus_repeat_em=float(delta.mean()) if len(delta) else None,paired_question_bootstrap_95ci=np.quantile(boots,[.025,.975]).tolist() if len(boots) else None,new_only_correct=sum(x['metrics']['em'] and not y['metrics']['em'] for x,y in zip(new,repeat)),repeat_only_correct=sum(y['metrics']['em'] and not x['metrics']['em'] for x,y in zip(new,repeat)),same_ordered_evidence=sum(x['evidence']['identical_ordered_documents'] for x in new),any_new_document=sum(x['evidence']['new_document_count']>0 for x in new),historical_new_branch_text_reproduced=sum(x['historical_text_exact'] for x in new))
 assert all(x['prefix_sha256']==y['prefix_sha256'] for x,y in zip(new,repeat))
 identical=[(x,y) for x,y in zip(new,repeat) if x['evidence']['identical_ordered_documents']]
 r['identical_evidence_output_mismatches']=sum([e['text'] for e in x['events']]!=[e['text'] for e in y['events']] for x,y in identical)
 out[condition]=r
result={'status':'COMPLETE_VALIDATED','conditions':out,'records':len(rows),'scope':'Paired intervention at observed second-search states. All-question results carry original outcomes for ineligible questions. Development only. New evidence is not guaranteed relevant or correct; this is not learned recovery. Bootstrap resamples questions within each condition. Shared prefix costs excluded from incremental continuation costs, allocation totals reported separately.'}
(HERE/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['condition | eligible/256 | new EM | repeat EM | difference pp | identical evidence | new docs | exact historical replay']
for c,r in out.items():lines.append(f"{c} | {r['eligible_states']}/256 | {100*r['branches']['new']['eligible_mean']['em']:.2f} | {100*r['branches']['repeat']['eligible_mean']['em']:.2f} | {100*r['new_minus_repeat_em']:+.2f} | {r['same_ordered_evidence']} | {r['any_new_document']} | {r['historical_new_branch_text_reproduced']}")
(HERE/'comparison.txt').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))
