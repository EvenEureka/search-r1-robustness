import os,json,time,hashlib,platform,argparse
from pathlib import Path
from core import prompt,digest
from branch import eligible,continue_branch
p=argparse.ArgumentParser();p.add_argument('--shard',type=int,required=True);a=p.parse_args()
HERE=Path(__file__).resolve().parents[1];plan=json.loads((HERE/'protocol.json').read_text());cfg=plan['evaluation'];spec=plan['model']
assert os.environ.get('JOB_ID') and platform.node().split('.')[0]=='qa-rtx6kbw-003'
import torch,transformers
from transformers import AutoModelForCausalLM,AutoTokenizer,StoppingCriteria,StoppingCriteriaList
assert torch.cuda.device_count()==1
torch.manual_seed(cfg['seed']);torch.set_num_threads(4)
out=HERE/'runs'/str(a.shard);out.mkdir(parents=True,exist_ok=False);start=time.monotonic()
tok=AutoTokenizer.from_pretrained(spec['path'],local_files_only=True)
model=AutoModelForCausalLM.from_pretrained(spec['path'],dtype=torch.bfloat16,attn_implementation='sdpa',local_files_only=True).to('cuda').eval()
work=dict(calls=0,requested_input_tokens=0,generated_tokens=0)
def count(s):return len(tok.encode(s,add_special_tokens=False))
def fmt(s):return tok.apply_chat_template([dict(role='user',content=s)],tokenize=False,add_generation_prompt=True) if tok.chat_template else s
class Stop(StoppingCriteria):
 def __init__(self,n):self.n=n
 def __call__(self,ids,scores,**kw):
  tail=tok.decode(ids[0,max(self.n,ids.shape[1]-32):],skip_special_tokens=True)
  return '</search>' in tail or '</answer>' in tail
@torch.inference_mode()
def generate(s):
 x=tok(s,add_special_tokens=False,return_tensors='pt').to('cuda');n=x['input_ids'].shape[1];assert n+cfg['max_new_tokens_per_turn']<=cfg['max_context_tokens']
 y=model.generate(**x,max_new_tokens=cfg['max_new_tokens_per_turn'],do_sample=False,pad_token_id=tok.eos_token_id,stopping_criteria=StoppingCriteriaList([Stop(n)]))
 work['calls']+=1;work['requested_input_tokens']+=n;work['generated_tokens']+=y.shape[1]-n
 return tok.decode(y[0,n:],skip_special_tokens=True)
samples={x['id']:x for x in map(json.loads,Path(plan['development']['path']).read_text().splitlines())}
source=Path(plan['trace_files'][a.shard]);rows=[json.loads(x) for x in source.read_text().splitlines()];rows=[r for r in rows if r['condition'] in plan['conditions']]
(out/'environment.json').write_text(json.dumps(dict(torch=torch.__version__,transformers=transformers.__version__,model=spec,job=os.environ['JOB_ID'],gpu=torch.cuda.get_device_name(0),protocol_sha256=hashlib.sha256((HERE/'protocol.json').read_bytes()).hexdigest()),indent=2))
n=0
with (out/'traces.jsonl').open('x') as f,(out/'eligibility.jsonl').open('x') as ef:
 for j,row in enumerate(rows):
  ef.write(json.dumps(dict(id=row['id'],condition=row['condition'],eligible=eligible(row)))+'\n');ef.flush()
  if not eligible(row):continue
  sample=samples[row['id']];initial=fmt(prompt(sample['question']))
  # Alternate branch execution order without selecting by outcome.
  branches=['new','repeat'] if int(digest(row['id']+row['condition'])[:8],16)%2==0 else ['repeat','new']
  for branch in branches:
   before=dict(work);t=time.monotonic();r=continue_branch(sample,row,initial,branch,cfg,generate,count)
   r['continuation_work']={k:work[k]-before[k] for k in work};r['continuation_seconds']=time.monotonic()-t
   # Compare semantic text/events separately because diagnostic adds one event field.
   if branch=='new':r['historical_text_exact']=[e['text'] for e in r['events']]==[e['text'] for e in row['events']] and r['stop_reason']==row['stop_reason']
   f.write(json.dumps(r)+'\n');f.flush();n+=1
  print('STATE',a.shard,j+1,len(rows),n,flush=True)
(out/'complete.json').write_text(json.dumps(dict(records=n,question_conditions=len(rows),work=work,seconds=time.monotonic()-start),indent=2))
