"""Paired second-retrieval intervention; prefix and policy action stay fixed."""
import copy
from core import action,observation,retrieve,digest,score_record

def eligible(row):
 e=row['events']
 return (len(e)>=3 and [x['role'] for x in e[:3]]==['assistant','tool','assistant']
         and e[1]['consumed'] and action(e[2]['text'])[0]=='search' and bool(action(e[2]['text'])[1]))

def continue_branch(sample,original,initial,branch,cfg,generate,count):
 assert eligible(original) and branch in ['new','repeat']
 assert digest(initial)==original['initial_prompt_sha256']
 events=copy.deepcopy(original['events'][:3]);text=initial+''.join(x['text'] for x in events)
 query=action(events[-1]['text'])[1]
 old=copy.deepcopy(events[1]['clean_documents']);fresh=retrieve(sample,query,cfg['topk'])
 row={k:original[k] for k in ['id','question','answers','condition','attack_target']}
 row.update(branch=branch,events=events,prefix_sha256=digest(text),second_query=query,
            initial_prompt_sha256=digest(initial),original_stop_reason=original['stop_reason'],
            evidence={'old_document_ids':[x['id'] for x in old], 'new_document_ids':[x['id'] for x in fresh],
                      'identical_ordered_documents':old==fresh,
                      'new_document_count':len({x['id'] for x in fresh}-{x['id'] for x in old})})
 for index in range(1,cfg['max_searches']):
  docs=(fresh if branch=='new' else old) if index==1 else retrieve(sample,query,cfg['topk'])
  obs=observation(docs);event=dict(role='tool',query=query,clean_documents=copy.deepcopy(docs),shown_documents=copy.deepcopy(docs),text=obs,injected=False,intervention_applied=False,consumed=False,branch_intervention=index==1)
  row['events'].append(event);text+=obs
  if index==1:row['second_input_tokens']=count(text)
  if count(text)+cfg['max_new_tokens_per_turn']>cfg['max_context_tokens']:
   row['stop_reason']='context_limit';break
  response=generate(text);event['consumed']=True;row['events'].append(dict(role='assistant',text=response));text+=response
  kind,content=action(response)
  if kind=='answer':row['stop_reason']='answer';break
  if kind!='search' or not content:row['stop_reason']='invalid_action_or_token_limit';break
  if index+1==cfg['max_searches']:row['stop_reason']='search_limit';break
  query=content
 metrics=score_record(row);metrics['scheduled_exposure']=metrics.pop('exposed')
 metrics['actual_exposure']=any(x.get('injected') and x.get('consumed') for x in row['events'])
 metrics['other_wrong']=int(not(metrics['em'] or metrics['target_hit'] or metrics['format_failure']))
 row['metrics']=metrics
 return row
