"""Simple action prompts; no labels, answer references, schema or forced choice."""
import re
def instructions(question):
 return ('Answer the given question. Reason inside <think> and </think>. To search, emit <search> query </search>; results appear inside <information> and </information>. '
         'You have at most two search calls. When ready, give a concise final answer inside <answer> and </answer>. Question: '+question+'\n')
def initial(tokenizer,interface,question,first_assistant,first_observation):
 if interface=='continuation':return tokenizer.apply_chat_template([{'role':'user','content':instructions(question)}],add_generation_prompt=True,tokenize=False)+first_assistant+first_observation
 assert interface=='fresh'
 text=(instructions(question)+'The documents below are the result of the first search. You may answer now or use one additional search.\n'+first_observation)
 return tokenizer.apply_chat_template([{'role':'user','content':text}],add_generation_prompt=True,tokenize=False)
def final_after_tool(prefix,search_action,observation):
 return prefix+search_action+observation+'\nSearch budget is exhausted. Give a concise final answer inside <answer> and </answer>.\n<answer>'
def closed_book(tokenizer,question):
 return tokenizer.apply_chat_template([{'role':'user','content':'Answer the following question without using tools. Give a concise answer inside <answer> and </answer>. Question: '+question}],add_generation_prompt=True,tokenize=False)+'<answer>'
def parse(text):
 matches=list(re.finditer(r'<(search|answer)>(.*?)</\1>',text,re.S))
 if len(matches)!=1 or not matches[0].group(2).strip():return 'invalid',''
 m=matches[0];kind=m.group(1)
 if text.count('<'+kind+'>')!=1 or text.count('</'+kind+'>')!=1:return 'invalid',''
 return kind,m.group(2).strip()
