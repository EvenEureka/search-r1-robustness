"""Post hoc paired outcome analysis; reads saved trajectories, never calls a model."""
import argparse
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--project-root', type=Path, required=True)
args = p.parse_args()
root = args.project_root.resolve()
out = Path(__file__).resolve().parent / 'data'
out.mkdir(exist_ok=True)
source = root / 'arr_study/confirmation_v1/source/scripts/evaluation.py'
spec = importlib.util.spec_from_file_location('frozen_scoring', source)
scoring = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scoring)
arms = ['random_matched', 'random_answer']
seeds = [20261012, 20261013, 20261014]
bank = {}
files = {}
def category(m):
    if m['em']: return 'correct'
    if m['target_hit']: return 'target'
    if m['format_failure']: return 'invalid'
    return 'other_wrong'

for seed in seeds:
    for arm in arms:
        rows = {}
        for file in sorted((root / f'arr_study/confirmation_v1/runs/s{seed}_{arm}/confirmation').glob('shard_*/traces.jsonl')):
            files[str(file.relative_to(root))] = hashlib.sha256(file.read_bytes()).hexdigest()
            with file.open() as f:
                for line in f:
                    r = json.loads(line)
                    m = scoring.score_record(r)
                    assert all(m[k] == r['metrics'][k] for k in m), (r['id'],r['condition'])
                    tools = [x for x in r['events'] if x['role'] == 'tool']
                    first = tools[0] if tools else {}
                    key = (r['id'], r['condition'])
                    assert key not in rows
                    rows[key] = {'metrics': m, 'question': r['question'], 'answers': r['answers'],
                        'query': first.get('query'),
                        'documents_sha256': hashlib.sha256(json.dumps(first.get('clean_documents', []), sort_keys=True).encode()).hexdigest(),
                        'category': category(m)}
        assert len(rows) == 5000
        bank[seed, arm] = rows

matrix = collections.Counter()
per_seed = {}
candidates = collections.defaultdict(list)
paired = []
for seed in seeds:
    by_seed = collections.Counter()
    b, s = bank[seed, arms[0]], bank[seed, arms[1]]
    assert b.keys() == s.keys()
    for (qid, condition), x in sorted(b.items()):
        if condition not in ['test_override', 'test_authority']: continue
        y = s[qid, condition]
        assert x['question'] == y['question'] and x['answers'] == y['answers']
        matrix[x['category'], y['category']] += 1
        by_seed[x['category'], y['category']] += 1
        bc, sc = b[qid, 'clean']['metrics'], s[qid, 'clean']['metrics']
        same_query = x['query'] is not None and x['query'] == y['query']
        same_docs = x['query'] is not None and y['query'] is not None and x['documents_sha256'] == y['documents_sha256']
        paired.append({'seed': seed, 'id': qid, 'condition': condition,
            'baseline': x['category'], 'supervised': y['category'],
            'same_query': same_query, 'same_clean_documents': same_docs,
            'baseline_clean_correct': bool(bc['em']), 'supervised_clean_correct': bool(sc['em'])})
        # Case selection is descriptive and post hoc. Use the first training seed,
        # both-clean-correct cases where possible, and deterministic ID ordering.
        if seed == seeds[0] and bc['em'] and sc['em']:
            key = (seed, qid, condition)
            if x['category'] == 'target' and y['category'] == 'correct' and same_query and same_docs:
                candidates['A_target_to_correct_same_retrieval'].append(key)
            if x['category'] == 'target' and y['category'] == 'other_wrong':
                candidates['B_target_avoidance_without_correctness'].append(key)
            if x['category'] == 'correct' and y['category'] != 'correct':
                candidates['C_regression'].append(key)
    per_seed[str(seed)] = {a+' -> '+b: n for (a,b),n in sorted(by_seed.items())}

selected = {name: sorted(values, key=lambda x:(x[1],x[2]))[0] for name, values in candidates.items()}
cases = {name: {'seed': k[0], 'id': k[1], 'condition': k[2], 'records': {}} for name,k in selected.items()}
for seed in seeds:
    for arm in arms:
        for file in sorted((root / f'arr_study/confirmation_v1/runs/s{seed}_{arm}/confirmation').glob('shard_*/traces.jsonl')):
            for line in file.open():
                r=json.loads(line)
                for name,k in selected.items():
                    if (seed,r['id']) == k[:2] and r['condition'] in ['clean',k[2],'quoted_target']:
                        # Keep question/evidence and generated action text, but no machine paths or model identifiers.
                        records = [{'role': ev['role'], 'text': ev['text'],
                            **{a:ev[a] for a in ['query','injected','clean_documents','shown_documents'] if a in ev}}
                            for ev in r['events']]
                        cases[name]['records'][arm + '/' + r['condition']] = {'events':records,'metrics':r['metrics'],
                            'question':r['question'],'answers':r['answers'],'stop_reason':r['stop_reason']}

summary = {'analysis_type':'POST_HOC_DESCRIPTIVE_SAVED_TRAJECTORY_ANALYSIS',
    'selection_rule':'First seed20261012; both clean answers correct; first lexicographic question/condition per outcome category. Case A also requires identical first query and clean retrieved documents. No retraining or new inference.',
    'pairs': len(paired), 'unique_questions': len({x['id'] for x in paired}),
    'transition_counts': {a+' -> '+b:n for (a,b),n in sorted(matrix.items())},
    'per_seed': per_seed, 'case_candidates': {k:len(v) for k,v in candidates.items()},
    'same_query_pairs':sum(x['same_query'] for x in paired),
    'same_retrieval_pairs':sum(x['same_clean_documents'] for x in paired),
    'both_clean_correct_pairs':sum(x['baseline_clean_correct'] and x['supervised_clean_correct'] for x in paired),
    'selected_cases': {name: {'seed':k[0],'id':k[1],'condition':k[2]} for name,k in selected.items()},
    'source_sha256': files,
    'limits':'6000 seed-question-template pairs share 1000 question identities. Counts are descriptive, not independent observations or causal recovery effects. Cases selected after confirmation; neither representative sampling nor new confirmation.'}
assert summary['pairs']==6000 and summary['unique_questions']==1000
assert sum(n for (a,b),n in matrix.items() if b=='correct') - sum(n for (a,b),n in matrix.items() if a=='correct') == 604
(out/'paired-analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'cases.json').write_text(json.dumps(cases,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='source_sha256'},indent=2))
for name,case in cases.items():
    print('\n',name,case['id'])
    for key,r in case['records'].items():
        print(key,r['question'],r['metrics']['answer'],r['metrics']['em'])
