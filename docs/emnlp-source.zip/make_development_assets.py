"""Render development tables from released, frozen aggregate records (no model calls)."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LABELS = {'clean': 'Clean', 'test_override': 'Override', 'test_authority': 'Authority',
          'neutral_override': 'Neutral / override', 'quoted_override': 'Quoted / override',
          'neutral_authority': 'Neutral / authority', 'quoted_authority': 'Quoted / authority'}

def render():
    cross = json.loads((ROOT/'data/cross-model-development.json').read_text())
    evidence = json.loads((ROOT/'data/evidence-branch-7b.json').read_text())
    assert cross['n_questions'] == 256 and evidence['records'] == 1128
    rows = []
    for condition, models in cross['conditions'].items():
        for model, record in models.items():
            v = record['rates']
            assert record['n'] == 256
            assert abs(sum(v[m] for m in ['em','target_hit','other_wrong','format_failure'])-1) < 1e-9
            row = [LABELS[condition], model.split('_')[-1].upper()]
            row += [f'{100*v[m]:.2f}' for m in ['em','target_hit','other_wrong','format_failure']]
            row += [f'{v["searches"]:.3f}', f'{100*v["actual_exposure"]:.0f}']
            rows.append(' & '.join(row) + r'\\')
    (ROOT/'generated/cross-model-development.tex').write_text('\n'.join(rows)+'\n')
    compact, detailed, costs = [], [], []
    for condition, r in evidence['conditions'].items():
        n = r['eligible_states']; new = r['branches']['new']; repeat = r['branches']['repeat']
        assert r['historical_new_branch_text_reproduced'] == n
        assert r['identical_evidence_output_mismatches'] == 0
        assert abs(r['new_minus_repeat_em']-(r['new_only_correct']-r['repeat_only_correct'])/n) < 1e-9
        compact.append(' & '.join([LABELS[condition], str(n), f'{100*new["eligible_mean"]["em"]:.2f}', f'{100*repeat["eligible_mean"]["em"]:.2f}', f'{100*r["new_minus_repeat_em"]:+.2f}']) + r'\\')
        for branch, record in r['branches'].items():
            m = record['eligible_mean']; cost = record['continuation_cost']
            detailed.append(' & '.join([LABELS[condition], branch.title(), str(n)] + [f'{100*m[k]:.2f}' for k in ['em','target_hit','other_wrong','format_failure']] + [f'{m["searches"]:.3f}', f'{100*record["all_question_mean"]["em"]:.2f}']) + r'\\')
            costs.append(' & '.join([LABELS[condition], branch.title(), str(cost['calls']), f'{cost["requested_input_tokens"]:,}', f'{cost["generated_tokens"]:,}', f'{record["continuation_seconds"]:.1f}']) + r'\\')
    for name, rows in [('evidence-branch-compact',compact),('evidence-branch-full',detailed),('evidence-branch-costs',costs)]:
        (ROOT/'generated'/f'{name}.tex').write_text('\n'.join(rows)+'\n')

if __name__ == '__main__':
    render()
